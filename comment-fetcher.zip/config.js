
import "./vendor/angular.js"
import "./vendor/angular-resource.js"
import "./vendor/angular-cookies.js"
 
const wallet = angular.module("wallet", ["ngResource", "ngCookies"]);
wallet.config(['$resourceProvider', function($resourceProvider) {
    // Don't strip trailing slashes from calculated URLs
    $resourceProvider.defaults.stripTrailingSlashes = false;
  }]);
wallet.controller("comments", ["$scope", "$resource",function($scope, $resource) {
        
        $scope.response = false
        $scope.getUserComment = function() { 
            let Student = $resource('https://jsonplaceholder.typicode.com/comments/:commentId')
            Student.get({commentId: this.commentnumber}, student => {
               $scope.body = student.body
               $scope.name = student.name 
               $scope.email = student.email
               $scope.userId = student.id
            })
            $scope.response = true
        }
    }])



